# opencv 로 컴퓨터 카메라 연결 + 카메라 영상 저장하기

import cv2
import sys

# 시스템 기본 카메라로 부터 cv2.VideoCaptuer 객체 생성
cap = cv2.VideoCapture(0)

if not cap.isOpened():  # 카메라 열기가 실패했다면 (다른 앱이 카메라를 사용 중인 경우)
    print('Camera open failed!')  # 카메라가 없거나, 카메라 드라이버 미설정
    sys.exit()

# 동영상 저장을 위한 cv2.VideoCapture 객체 생성
w = round(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
h = round(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
fps = round(cap.get(cv2.CAP_PROP_FPS))
fourcc = cv2.VideoWriter_fourcc(*'DIVX')  # 'DIVX' == 'D', 'I', 'V', 'X'

out = cv2.VideoWriter('../multi/output3.avi',fourcc, fps, (w,h))

# 매 프레임 처리 및 화면 출력 (영상 출력)
while True:
    ret, frame = cap.read()
    # frame : 카메라로 부터 읽은 프레임(화면) 정보 저장
    # ret : 읽기 성공 여부 저장 (True | False)

    if not ret:  # ret 가 False 이면 (읽기 실패 의미함)
        break  # while 강제 종료

    # 읽은 영상을 화면에 출력 처리
    cv2.imshow('frame',frame)  # 윈도우 창이 열리면서 영상이 출력됨

    # 읽은 영상에서 테두리(경계, edge)선으로 변환해서 출력
    edge = cv2.Canny(frame, 50, 150)
    edge = cv2.cvtColor(edge, cv2.COLOR_GRAY2BGR)
    cv2.imshow('edge',edge) # 윈도우 창이 열리면서 경계선 처리 영상 출력됨

    out.write(frame)   # 파일에도 저장

    if cv2.waitKey(10) == 27:  # esc 키를 누르면 (영상 윈도우 창에서)
        break
# while end ----------------

cap.release()  # 카메라 자원 해제
out.release()   # 파일 출력 스트림 해제
cv2.destroyAllWindows()  # 윈도우 창 모두 닫기
