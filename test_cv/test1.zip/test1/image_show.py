import cv2
import sys

# 이미지 파일 불러오기
img = cv2.imread('../images/cat.bmp')  # 상대경로

if img is None:  # 해당 이미지가 없다면
    print('image load failed')
    sys.exit()

print(type(img))
print(img.shape)

# 읽은 이미지 출력
cv2.namedWindow('imgshow')
cv2.imshow('imgshow', img)
cv2.waitKey()   # 키보드 입력이 있을 때까지 기다림

# 창닫기
cv2.destroyAllWindows()