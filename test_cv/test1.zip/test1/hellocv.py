# pip install opencv-python
# numpy 도 함께 설치함

import cv2

print('Hello OpenCV', cv2.__version__)
